<!DOCTYPE html>
<!-- saved from url=(0097)https://pixinvent.com/bootstrap-admin-template/robust/html/ltr/horizontal-top-icon-menu-template/ -->
<html lang="en" data-textdirection="LTR" class="loaded">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">.gm-style .gm-style-mtc label,.gm-style .gm-style-mtc div{font-weight:400}
</style><link type="text/css" rel="stylesheet" href="<?php echo base_url() ?>assets/assets_in/css">
<style type="text/css">.gm-style .gm-style-cc span,.gm-style .gm-style-cc a,.gm-style .gm-style-mtc div{font-size:10px}
</style>
<style type="text/css">@media print {  .gm-style .gmnoprint, .gmnoprint {    display:none  }}@media screen {  .gm-style .gmnoscreen, .gmnoscreen {    display:none  }}</style>
<style type="text/css">.gm-style-pbc{transition:opacity ease-in-out;background-color:rgba(0,0,0,0.45);text-align:center}.gm-style-pbt{font-size:22px;color:white;font-family:Roboto,Arial,sans-serif;position:relative;margin:0;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)}
</style>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Administrator Nucleus Farma">
    <meta name="keywords" content="#">
    <meta name="author" content="PIXINVENT">
    <title>Administrator Nucleus Farma</title>
    <link rel="apple-touch-icon" sizes="60x60" href="#">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/font-awesome-4.7.0/css/font-awesome.css">
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/icomoon.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/flag-icon.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/slick.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/pace.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/icheck.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/custom.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/morris.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/unslider.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/climacons.min.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/app.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/colors.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/style.css">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/horizontal-top-icon-menu.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/vertical-overlay-menu.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/palette-climacon.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/users.min.css">
    <!-- END Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/assets_in/style.css">
    <!-- END Custom CSS-->
  <script async="" src="<?php echo base_url() ?>assets/assets_in/analytics.js"></script>
  <script data-require-id="echarts/chart/pie" src="<?php echo base_url() ?>assets/assets_in/pie.js" async=""></script>
  <script data-require-id="echarts/chart/funnel" src="<?php echo base_url() ?>assets/assets_in/funnel.js" async=""></script>
  <style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}
  </style>
  <style type="text/css">.gm-style {
        font: 400 11px Roboto, Arial, sans-serif;
        text-decoration: none;
      }
      .gm-style img { max-width: none; }
  </style>
</head>