<footer class="footer undefined footer-dark">
      <p class="clearfix text-muted text-sm-center mb-0 px-2"><span class="float-md-left d-xs-block d-md-inline-block">Copyright  © 2017 <a href="#" target="_blank" class="text-bold-800 grey darken-2">Nucleus Farma </a>, All rights reserved. </span></p>
    </footer>

    <!-- BEGIN VENDOR JS-->
    <!-- build:js app-assets/js/vendors.min.js-->
    <script src="<?php echo base_url()?>/assets/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/tether.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/unison.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/blockUI.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/jquery-sliding-menu.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/slick.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/screenfull.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/pace.min.js" type="text/javascript"></script>
    <!-- /build-->
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script type="text/javascript" src="<?php echo base_url()?>/assets/assets_in/jquery.sticky.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>/assets/assets_in/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/gmaps.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/icheck.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/jquery.knob.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/raphael-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/morris.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/unslider-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/echarts.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
    <!-- build:js app-assets/js/app.min.js-->
    <script src="<?php echo base_url()?>/assets/assets_in/app-menu.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/app.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/fullscreenSearch.min.js" type="text/javascript"></script>
    <!-- /build-->
    <!-- END ROBUST JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script type="text/javascript" src="<?php echo base_url()?>/assets/assets_in/breadcrumbs-with-stats.min.js"></script>
    <script src="<?php echo base_url()?>/assets/assets_in/dashboard-fitness.min.js" type="text/javascript"></script>
    <script id="wappalyzer" src="<?php echo base_url()?>/assets/chrome_in-extension://gppongmhjkpfnbhagpmjfkannfbllamg/js/inject.js"></script>
</body>
</html>