    <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><!--fitness stats-->
          <div class="row">
              <div class="col-xs-12">
                  <div class="card border-top-tosca">
                      <div class="card-header no-border-bottom">
                          <h4 class="card-title">Daily Sales Outlet</h4>
                          <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                          <div class="heading-elements">
                              <ul class="list-inline mb-0">
                                  <li><a data-action="reload"><i class="fa fa-refresh"></i></a></li>
                              </ul>
                          </div>
                      </div>
                      <div class="card-body collapse in">
                          <div id="daily-activity" class="table-responsive height-250 ps-container ps-theme-default ps-active-y" data-ps-id="919f8169-8f2a-e62c-bd13-883a2a99a52f">
                              <table class="table table-hover mb-0">
                                  <thead>
                                      <tr>
                                          <th>Kode</th>
                                          <th>Kota/Area</th>
                                          <th>Sales Reg</th>
                                          <th>Sales PTKP</th>
                                          <th>Sales PPG</th>
                                          <th>Sales Penta</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php for ($i=0; $i < 5; $i++) { 
                                      # code...
                                     ?>
                                      <tr>
                                          <td class="text-truncate">007</td>
                                          <td class="text-truncate">Jakarta Selatan</td>
                                          <td class="text-truncate">200.000.000</td>
                                          <td class="text-truncate">200.000.000</td>
                                          <td class="text-truncate">200.000.000</td>
                                          <td class="text-truncate">200.000.000</td>
                                          
                                      </tr>
                                      <?php }?>
                                  </tbody>
                              </table>
                          <div class="ps-scrollbar-x-rail" style="left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 350px; right: 3px;"><div class="ps-scrollbar-y" tabindex="0" style="top: 0px; height: 307px;"></div></div></div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>